def do_pins(name):
    return ["%s%d" % (name, i) for i in range(8)]

ports = {"PORTA" : do_pins("PA"),
        "PORTB" : do_pins("PB"),
        "PORTC" : do_pins("PC"),
        "PORTD" : do_pins("PD")}

def check_count(value):
    try:
        num = int(value)
        if 0 < num <= 8:
            return True
    except ValueError:
        pass
    return False

def check_delay(value):
    try:
        num = int(value)
        if 0 < num < 1000:
            return True
    except ValueError:
        pass
    return False

COUNT = cfg.input("COUNT", type='int', check=check_count, help="Number of buttons you want to configure.")
PORT = cfg.single("PORT", ports.keys(), help="The port on which all buttons are located.")
cfg.input("READ_DELAY", type='int', check=check_delay, help="short delay (us) between setting DDR and reading in value of pin.")
INTERRUPT = cfg.single("INTERRUPT", ["INT0", "INT1", "INT2"])

@cfg.depends(INTERRUPT)
def set_interrupt_stuff(intr):
    
    cfg.define("INT_FLAG", "INTF" + intr.lstrip("INT"))
    if intr == "INT0":
        cfg.define("SET_INT_SENSE", "cbi(MCUCR, ISC00);cbi(MCUCR, ISC01);")
        cfg.define("INT_DDR", "DDRD")
        cfg.define("INT_PORT", "PORTD")
        cfg.define("INT_PIN", "PIND")
        cfg.define("PINT", "PD2")
    elif intr == "INT1":
        cfg.define("SET_INT_SENSE", "cbi(MCUCR, ISC10);cbi(MCUCR, ISC11);")
        cfg.define("INT_DDR", "DDRD")
        cfg.define("INT_PORT", "PORTD")
        cfg.define("INT_PIN", "PIND")
        cfg.define("PINT", "PD3")
    elif intr == "INT2":
        cfg.define("SET_INT_SENSE", "cbi(MCUCSR, ISC2);")
        cfg.define("INT_DDR", "DDRB")
        cfg.define("INT_PORT", "PORTB")
        cfg.define("INT_PIN", "PINB")
        cfg.define("PINT", "PB2")

@cfg.depends(PORT)
def set_port_ddr_and_pin(p):
    cfg.define("DDR", "DDR" + p.lstrip("PORT"))
    cfg.define("PIN", "PIN" + p.lstrip("PORT"))

@cfg.depends(PORT, COUNT)
def choose_button_pins(port, count):
    pins = ports[port]
    pl = list()
    for i in range(int(count)):
        pl.append(cfg.single("PIN_%d" % i, pins))
    
    @cfg.depends(*pl)
    def set_mask(*pins):
        mask = "(" + " | ".join(["_BV(" + i + ")" for i in pins]) + ")"
        cfg.define("MASK", mask)
        cfg.define("PINS", pins)

