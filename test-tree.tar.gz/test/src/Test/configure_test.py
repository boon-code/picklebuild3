#$ use FUNNY -n mu
a = cfg.expr("BLA")

b = cfg.single("WIRKLICH", ["JA", "NEIN"])
c = cfg.multi("KAFFEE", ["Schwarz", "mit Zucker", "mit Milch"])
#d = cfg.single('BLA2', mu.HUI, help="something")
