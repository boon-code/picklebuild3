#ifndef _BUTTONS_MOD_
#define _BUTTONS_MOD_

#include "configure_BUTTON.h"

#define BUTTON_ISR_NAME <?py:echo(BUTTON_INTERRUPT + '_vect')?>

extern volatile unsigned char g_button;

void button_init(void);
unsigned char button_begintest(unsigned int times);
void button_endtest(void);

#endif
