#$ ext bla bla bla
#$ use NEWM

extra = cfg.single("EXTRAS", ["SUPER", "NORMAL", "BAD"])


