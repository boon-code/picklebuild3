#$ use FUNNY -n mu
a = cfg.expr("BLA")

b = cfg.single("WIRKLICH", ["JA", "NEIN"])
c = cfg.multi("KAFFEE", ["Schwarz", "mit Zucker", "mit Milch"])
x = cfg.single("ENABLE_SOME", [True, False], viewlist=["YES", "NO"])

h = cfg.define("SOME", "VALUE", flags=[x])
@cfg.depends(b)
def func1(wirklich):
	values = ["YES", "COOL", "NO", "NOT AT ALL"]
	if wirklich == 'JA':
		values.append("AUCH JA")
	print(wirklich)
	d = cfg.single("WORKS", values)
	
	if wirklich == 'JA':
		@cfg.depends(d, b)
		def func2(d, b):
			print("*** func2 *** ", d, b, wirklich)
			g = cfg.expr("TEXT")
			
			@cfg.depends(g)
			def func3(g):
				cfg.define("HUI", g + "bla bla")
				cfg.define("BUH", g + "la la")
	else:
		@cfg.depends(d)
		def func4(d):
			cfg.expr("HUI")
	
@cfg.depends(mu.EXTRAS)
def extrafu(ex):
	print("extra")
	cfg.define("EXTRA", ex + "tra")