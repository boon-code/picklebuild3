def do_pins(name):
    return ["%s%d" % (name, i) for i in range(8)]

def check_reinit_count(value):
    try:
        number = int(value)
        if number < 10 and number > 0:
            return True
    except ValueError:
        pass
    return False

ports = {"PORTA" : do_pins("PA"),
        "PORTB" : do_pins("PB"),
        "PORTC" : do_pins("PC"),
        "PORTD" : do_pins("PD")}

fs_port = cfg.single("FS_PORT", ports.keys(), help="Choose function pin port")
d_port = cfg.single("DATA_PORT", ports.keys(), help="Choose data port")
cfg.expr("REINIT_COUNT", check=check_reinit_count, help="This must be an integer in range [1,10]")
lmode = cfg.single("LINE_MODE", ['one line', 'two line'], help="Set up line mode")

@cfg.depends(fs_port)
def choose_fs_pins(tport):
    cfg.define("FS_DDR", "DDR" + tport.lstrip('PORT'))
    cfg.single("FS_RS", ports[tport], help="The RS pin")
    cfg.single("FS_EN", ports[tport], help="The EN pin")
    cfg.single("FS_RW", ports[tport], help="The RW pin")

@cfg.depends(d_port)
def choose_d_lsb_pin(d_port):
    cfg.define("DATA_DDR", "DDR" + d_port.lstrip('PORT'))
    cfg.define("DATA_PIN", "PIN" + d_port.lstrip('PORT'))
    cfg.single("LSB_PIN", [ports[d_port][i] for i in range(5)], help="Choose LSB pin")

@cfg.depends(lmode)
def create_function_set(mode):
    if mode == 'one line':
        cfg.define("FUNCTION_SET", "(FUNCTION_SET_BASIC)")
    elif mode == 'two line':
        cfg.define("FUNCTION_SET", "(FUNCTION_SET_BASIC | FS_TWO_LINE)")

