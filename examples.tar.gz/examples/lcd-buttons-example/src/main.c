#define F_CPU F_OSC

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <util/delay.h>

#include "global.h"

#include "uart.h"
#include "rfm12.h"
#include "tlcd.h"
#include "button.h"

void send(void);
void receive(void);

ISR(BUTTON_ISR_NAME)
{
  unsigned char result;
  result = button_begintest(1800);
  
  if(result == _BV(0))
  {
  	clear_screen();
  }
  
  if(result == _BV(1))
  {
  	blink();
  }
  
  if(result == (_BV(1) | _BV(2)))
  {
  	blink();
  	blink();
  }
  
  if(result == (_BV(2) | _BV(0)))
  {
  	clear_screen();
  	tlcd_str("testing");
  }
  
  _delay_ms(5);
  button_endtest();
}

void blink(void)
{
  unsigned char i = 20;
  for(; i > 0; --i)
  {
    sbi(PORTD, PD6);
    _delay_ms(50);
    cbi(PORTD, PD6);
    _delay_ms(50);
  }
}

int main(void)
{
	DDRD = _BV(PD6);
	PORTD = _BV(PD6);
	
	tlcd_init();
	_delay_ms(1000);
	
	tlcd_str("init uart ");
	tlcd_write_hexi(9600);
	uart_init(9600);
	_delay_ms(1000);
	tlcd_set_ddram(0x40);
	sbi(PORTD, PD6);
	tlcd_str("done");
	_delay_ms(1000);
	clear_screen();
	
	sbi(PORTD, PD6);
	
	rfm_init();
	rfm_frequency(433.92);
	rfm_bandwidth(4, 1, 4);
	rfm_baudrate(19200);
	rfm_power(4, 0);
  
  cbi(PORTD, PD6);
  
  button_init();
  
  sei();
  
	while(1)
	{
	  receive();
	}
}

void receive(void)
{	
  unsigned char test[14];
  
	rfm_simple_rx(test, 14);
	sbi(PORTD, PD6);
	
	test[13] = 0;
	
	clear_screen();
	tlcd_str(test);
	cbi(PORTD, PD6);
}

void send(void)
{
  unsigned char test[14]="433-MHz Test\n";	
	rfm_simple_tx(test, 14);
}

