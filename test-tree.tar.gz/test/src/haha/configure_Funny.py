#$ ext bla bla bla
#$ use NEWM
#$ new ha bla

